import "..css/style.scss";

//Our modules / classes
import GoogleMap from "./modules/map";

const googleMap = new GoogleMap();
